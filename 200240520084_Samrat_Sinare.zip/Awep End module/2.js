
 function validation()
 {

       var name = document.getElementById("input1").value;

       var pass = document.getElementById("input2").value;

        
         if(name == " " || pass == " ")
         {
             alert("User name and password should not be blank");
         }

         else
         {
             alert("thanks for login");
         }

           var refname = document.querySelector("#refname");

           var refpass = document.querySelector("#refpass");

           
          
             refname.textContent = name;

             refpass.textContent = pass;
             
              var name = document.querySelector("#input1").value = " ";

              var pass = document.querySelector("#input2").value = " ";



            
  

      
   
 }
